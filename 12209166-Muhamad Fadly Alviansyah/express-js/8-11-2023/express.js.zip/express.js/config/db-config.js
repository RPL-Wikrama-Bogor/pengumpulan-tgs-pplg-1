module.exports = {
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'db_express_buku'
}