<?php 
    $i = 1;
    while ($i <= 50) {
        echo $i . "<br/>";
        $i++;
    }
?>