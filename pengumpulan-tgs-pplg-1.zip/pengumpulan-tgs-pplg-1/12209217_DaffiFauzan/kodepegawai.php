<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>kodepegawai</title>
</head>
<body>
    <form action="" method="post">
      <h1>Kode Pegawai</h1>
        <input type="number" name="kode" placeholder="kode">
        <button type="submit" name="submit">Submit</button>
    </form>

    <?php
    
    if (isset($_POST['submit'])) {
        
    }
    
    ?>
</body>
</html>