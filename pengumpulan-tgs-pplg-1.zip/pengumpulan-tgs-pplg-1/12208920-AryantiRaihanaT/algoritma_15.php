<?php 

$i = 1;

for($i = 1; $i <= 50; $i++){
    if($i % 2 == 0){
        echo "$i bilangan genap <br>";
    }
}

?>