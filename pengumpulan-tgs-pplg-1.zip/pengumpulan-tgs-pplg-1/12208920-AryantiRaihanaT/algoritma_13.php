<?php 

$i = 1;

for($i = 1; $i <=50; $i++){
    echo "$i <br>";
}

?>