<?php 

$i = 1;

for($i = 1; $i <=50; $i++){
    if($i % 2 == 1){
        echo "$i bilangan ganjil <br>";
    }else{
        echo "$i bilangan genap <br>";
    }
}

?>