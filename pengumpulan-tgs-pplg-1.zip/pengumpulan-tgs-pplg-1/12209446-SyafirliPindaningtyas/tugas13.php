<?php
$i;

$i = 1;

?>