<?php
for ($i = 1; $i <= 50; $i++) {
    if ($i % 2 == 1) {
        echo "Bilangan Ganjil " . ":" . $i;
        echo "<br>";
    }elseif ($i % 2 == 0) {
        echo "Bilangan Genap " . ":" . $i;
        echo "<br>";
    }
    
}
?>