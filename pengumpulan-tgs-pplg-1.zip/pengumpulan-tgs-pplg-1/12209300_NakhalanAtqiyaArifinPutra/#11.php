

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pengulangan</title>
</head>
<body>
    <?php
$i=0;
for($i; $i <= 50; $i++){
    echo $i."<br>";
}
?>
</body>
</html>