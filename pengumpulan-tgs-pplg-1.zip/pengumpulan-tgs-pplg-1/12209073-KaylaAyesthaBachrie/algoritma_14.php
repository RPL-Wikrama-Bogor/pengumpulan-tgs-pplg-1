<?php 
    $i = 1;
    while ($i <= 50) {
        if ($i % 2 == 1) {
            echo $i . " - Ganjil <br/>";
        }
        $i++;
    }
?>
