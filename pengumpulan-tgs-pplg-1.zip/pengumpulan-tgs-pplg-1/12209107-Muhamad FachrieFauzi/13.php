<?php

for($i=1; $i<=50; $i++){
  echo $i . "<br>";
}

?>