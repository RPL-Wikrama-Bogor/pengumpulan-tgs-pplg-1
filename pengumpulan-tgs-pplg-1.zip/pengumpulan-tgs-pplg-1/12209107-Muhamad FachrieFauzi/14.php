<?php

for($i=1; $i<=50; $i++){
  if($i%2==1){
    echo $i . "<br>";
  }
}

?>