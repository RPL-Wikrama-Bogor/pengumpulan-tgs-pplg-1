<!DOCTYPE html>
<html>

<head>
    <title>Deskripsi Angka</title>
</head>

<body>
    <h1>Deskripsi Angka</h1>
    <form action="deskripsi.php" method="post">
        <label for="bilangan">Masukkan Bilangan Bulat:</label>
        <input type="number" name="bilangan" id="bilangan" required><br>
        <input type="submit" value="Deskripsi">
    </form>
</body>

</html>