<!DOCTYPE html>
<html>

<head>
    <title>Cek Cuaca</title>
</head>

<body>
    <h1>Cek Cuaca</h1>
    <form action="cek_cuaca.php" method="post">
        <label for="temperatur">Masukkan Temperatur (°Fahrenheit):</label>
        <input type="number" name="temperatur" id="temperatur" required><br>
        <input type="submit" value="Cek Cuaca">
    </form>
</body>

</html>