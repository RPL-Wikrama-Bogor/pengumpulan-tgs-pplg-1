<!DOCTYPE html>
<html>

<head>
    <title>Kalkulator Harga Buah Jeruk</title>
</head>

<body>
    <h1>Kalkulator Harga Buah Jeruk</h1>
    <form action="hitung.php" method="post">
        <label for="berat">Berat Buah Jeruk (gram):</label>
        <input type="number" name="berat" id="berat" required><br>
        <input type="submit" value="Hitung">
    </form>
</body>

</html>