<!DOCTYPE html>
<html>

<head>
    <title>Cetak Bilangan</title>
</head>

<body>
    <h1>Cetak Bilangan 1 s.d 50 Menggunakan For Loop</h1>
    <ul>
        <?php
        for ($i = 1; $i <= 50; $i++) {
            echo "<li>$i</li>";
        }
        ?>
    </ul>
</body>

</html>