<!DOCTYPE html>
<html>

<head>
    <title>Konversi Total Detik ke Waktu</title>
</head>

<body>
    <h1>Konversi Total Detik ke Waktu</h1>
    <form action="konversi.php" method="post">
        <label for="totalDetik">Total Detik:</label>
        <input type="number" name="totalDetik" id="totalDetik" required><br>
        <input type="submit" value="Konversi">
    </form>
</body>

</html>