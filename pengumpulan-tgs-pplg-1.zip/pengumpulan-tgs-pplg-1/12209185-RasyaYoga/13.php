<!DOCTYPE html>
<html>
<head>
    <title>Mencetak Angka 1 sampai 50</title>
</head>
<body>

<h2>Mencetak Angka 1 sampai 50</h2>

<?php
$angka = 1;

while ($angka <= 50) {
    echo $angka . "<br>";
    $angka++;
}
?>

</body>
</html>
