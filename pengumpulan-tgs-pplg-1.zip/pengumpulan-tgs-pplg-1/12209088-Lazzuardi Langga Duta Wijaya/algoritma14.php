<?php
for ($i = 1; $i <= 50; $i += 2) {
    echo $i . "<br> ";
}
