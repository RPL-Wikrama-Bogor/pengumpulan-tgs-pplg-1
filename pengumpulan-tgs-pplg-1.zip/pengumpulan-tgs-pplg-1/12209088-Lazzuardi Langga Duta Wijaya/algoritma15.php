
<?php

    for ($i = 2; $i <= 50; $i += 2) {
        echo $i . " ";
    }

?>


