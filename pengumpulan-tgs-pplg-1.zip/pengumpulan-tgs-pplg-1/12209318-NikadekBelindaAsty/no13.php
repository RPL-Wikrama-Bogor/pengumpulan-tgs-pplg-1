<?php
$a;
for($a = 1; $a >=50; $a++){
    echo $a;
}
?>