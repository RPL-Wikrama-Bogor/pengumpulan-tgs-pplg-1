<?php 

for($i = 1; $i <= 50 ; $i++){
    if($i % 2 !== 0){
        echo $i . " Adalah Bilangan Ganjil" .  "<br>";
    }
    else{
        echo $i . " Adalah Bilangan Genap" .  "<br>";
    }
}


?>