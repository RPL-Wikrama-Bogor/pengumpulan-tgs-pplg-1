<?php 
    for($i=1; $i<=50; $i++){
        if($i % 2==1 ){
            echo "Ini bilangan ganjil: ". $i ."<br>";
        }
        elseif($i % 2==0 ){
            echo "Ini bilangan genap: ". $i ."<br>";
        }
    }
?>